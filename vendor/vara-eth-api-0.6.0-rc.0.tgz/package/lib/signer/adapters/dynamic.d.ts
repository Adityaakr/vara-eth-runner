import type { Hash, Hex, TransactionRequest } from 'viem';
import type { ITransactionSigner, SignTypedDataParams } from '../../types/signer.js';
/**
 * A signer that delegates to whatever signer is returned by the provided getter at call time.
 * Useful in reactive environments (e.g. React) where the underlying wallet client can change
 * without wanting to recreate the EthereumClient or MirrorClient instances.
 *
 * @example
 * ```ts
 * // Create once
 * const signer = new DynamicSigner(() =>
 *   walletClient ? walletClientToSigner(walletClient) : undefined
 * );
 * ethClient.setSigner(signer);
 *
 * // Later, when walletClient changes — just update the variable.
 * // No setSigner call needed.
 * walletClient = newWalletClient;
 * ```
 */
export declare class DynamicSigner implements ITransactionSigner {
    private _getSigner;
    constructor(_getSigner: () => ITransactionSigner | undefined);
    private get _signer();
    signMessage(message: Uint8Array | string): Promise<Hash>;
    getAddress(): Promise<`0x${string}`>;
    sendTransaction(tx: TransactionRequest): Promise<Hash>;
    signTypedData(params: SignTypedDataParams): Promise<Hex>;
}
