import type { Address, Hash, Hex } from 'viem';
/**
 * Stable string codes attached to every {@link VaraEthError}. Switch on these
 * (`err.code === VaraEthErrorCode.PromiseTimeout`) rather than `err.message`
 * — messages may change.
 */
export declare const VaraEthErrorCode: {
    readonly ViemForkRequired: "VIEM_FORK_REQUIRED";
    readonly InjectedTxStale: "INJECTED_TX_STALE";
    readonly PromiseTimeout: "PROMISE_TIMEOUT";
    readonly PromiseSigInvalid: "PROMISE_SIG_INVALID";
    readonly PermitExpired: "PERMIT_EXPIRED";
    readonly BlobUnderpriced: "BLOB_UNDERPRICED";
    readonly CodeValidationTimeout: "CODE_VALIDATION_TIMEOUT";
    readonly NoSailsIdl: "NO_SAILS_IDL";
    readonly RpcConnectionFailed: "RPC_CONNECTION_FAILED";
    readonly ChainIdMismatch: "CHAIN_ID_MISMATCH";
    readonly MessageReverted: "MESSAGE_REVERTED";
};
export type VaraEthErrorCode = (typeof VaraEthErrorCode)[keyof typeof VaraEthErrorCode];
/**
 * Base class for all typed errors thrown by `@vara-eth/api` public APIs.
 *
 * Sub-classes carry a stable {@link VaraEthErrorCode} for programmatic matching.
 * The `cause` chain is preserved when a typed error wraps an underlying viem /
 * JSON-RPC / network error.
 *
 * Sub-classes set `name` automatically via `new.target.name`.
 */
export declare class VaraEthError extends Error {
    readonly code: VaraEthErrorCode;
    constructor(code: VaraEthErrorCode, message: string, options?: {
        cause?: unknown;
    });
}
export declare class ViemForkRequiredError extends VaraEthError {
    constructor(cause?: unknown);
}
export declare class InjectedTxStaleError extends VaraEthError {
    constructor(referenceBlock: Hex, currentBlockNumber: bigint, cause?: unknown);
}
export declare class PromiseTimeoutError extends VaraEthError {
    readonly txHash: Hash;
    constructor(txHash: Hash, timeoutMs: number, cause?: unknown);
}
export declare class PromiseSignatureInvalidError extends VaraEthError {
    /** Address recovered from the signature, if the recovery step itself succeeded. Undefined when recovery failed. */
    readonly recoveredAddress: Address | undefined;
    constructor(recoveredAddress: Address | undefined, cause?: unknown);
}
/**
 * EIP-2612 permit signature was rejected because the deadline elapsed before
 * inclusion. Note: ethexe's Router wraps `WVARA.permit()` in `try {} catch {}`
 * (see `Router.sol` `requestCodeValidation`), so an on-chain expired-permit
 * call does NOT revert at the permit step — it falls through to
 * `transferFrom`, which only reverts if the user has no standing allowance.
 * This typed error is therefore most useful on:
 *  - first-time deploys (no prior approval), where transferFrom revert is the
 *    real signal,
 *  - client-side pre-checks (sign-time `now > deadline`),
 *  - other permit-only flows the lib may add later.
 */
export declare class PermitExpiredError extends VaraEthError {
    constructor(deadline: bigint, now: bigint, cause?: unknown);
}
export declare class BlobUnderpricedError extends VaraEthError {
    constructor(maxFeePerBlobGas: bigint, baseFeePerBlobGas: bigint, cause?: unknown);
}
/**
 * `requestCodeValidation` was committed but `CodeGotValidated` did not fire
 * within the caller's timeout. The code-validation tx is on-chain; resume the
 * deploy by calling `router.createProgramBuilder(codeId).build()` (with a
 * fresh executable-balance permit if needed) once validators commit
 * out-of-band. The `codeId`, `txHash`, and `timeoutMs` fields carry everything
 * the caller needs to do that resume.
 */
export declare class CodeValidationTimeoutError extends VaraEthError {
    readonly codeId: Hex;
    readonly txHash: Hash;
    readonly timeoutMs: number;
    constructor(codeId: Hex, txHash: Hash, timeoutMs: number, cause?: unknown);
}
export declare class NoSailsIdlError extends VaraEthError {
    constructor();
}
export declare class RpcConnectionError extends VaraEthError {
    readonly endpoint?: string;
    constructor(endpoint: string | undefined, cause?: unknown);
}
export declare class ChainIdMismatchError extends VaraEthError {
    constructor(expected: number, got: number);
}
/**
 * A Mirror contract call (`sendMessage`, `sendReply`, etc.) reverted at simulation
 * or broadcast time. `reason` is the decoded `ErrorName(args)` form when the
 * selector was matched against the Mirror/Router ABIs, or a generic string when
 * the selector was unknown.
 *
 * The `functionName` field identifies which contract entry-point reverted so
 * callers can branch on it (e.g. ignore reverts on `sendReply` for stale msgs).
 */
export declare class MessageRevertedError extends VaraEthError {
    readonly reason: string;
    readonly functionName: string;
    constructor(reason: string, functionName: string, cause?: unknown);
}
