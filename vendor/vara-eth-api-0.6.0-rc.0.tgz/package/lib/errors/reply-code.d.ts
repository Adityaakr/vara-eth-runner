import { type Hex } from 'viem';
export declare enum EReplyCode {
    Success = 0,
    Error = 1
}
export declare enum ESuccessReply {
    Auto = 0,
    Manual = 1
}
export declare enum ESimpleExecutionError {
    RanOutOfGas = 0,
    MemoryOverflow = 1,
    BackendError = 2,
    UserspacePanic = 3,
    UnreachableInstruction = 4,
    StackLimitExceeded = 5
}
export declare enum ESimpleUnavailableActorError {
    ProgramExited = 0,
    InitializationFailure = 1,
    Uninitialized = 2,
    ProgramNotCreated = 3,
    ReinstrumentationFailure = 4
}
declare abstract class ReplyCodeDetails {
    protected _bytes: Uint8Array;
    constructor(_bytes: Uint8Array);
    abstract get reason(): string;
    protected validateDetailsAccess(expectedReason: number, actualReason: number, reasonTypeName: string): void;
}
export declare class ReplyCode extends ReplyCodeDetails {
    private constructor();
    static fromBytes(value: Hex): ReplyCode;
    toBytes(): Uint8Array<ArrayBuffer>;
    get isSuccess(): boolean;
    get isError(): boolean;
    get asSuccess(): SuccessReply;
    get asError(): ErrorReply;
    get reason(): string;
}
declare class SuccessReply extends ReplyCodeDetails {
    get reason(): string;
    get isAuto(): boolean;
    get isManual(): boolean;
}
declare class ErrorReply extends ReplyCodeDetails {
    get reason(): string;
    get isExecution(): boolean;
    get asExecution(): ExecutionError;
    get isUnavailableActor(): boolean;
    get asUnavailableActor(): UnavailableActorError;
    get isRemovedFromWaitlist(): boolean;
}
declare class ExecutionError extends ReplyCodeDetails {
    get reason(): string;
    get isRanOutOfGas(): boolean;
    get isMemoryOverflow(): boolean;
    get isBackendError(): boolean;
    get isUserspacePanic(): boolean;
    get isUnreachableInstruction(): boolean;
    get isStackLimitExceeded(): boolean;
}
declare class UnavailableActorError extends ReplyCodeDetails {
    get reason(): string;
    get isProgramExited(): boolean;
    get isInitializationFailure(): boolean;
    get isUninitialized(): boolean;
    get isProgramNotCreated(): boolean;
    get isReinstrumentationFailure(): boolean;
}
export type { ErrorReply, ExecutionError, SuccessReply, UnavailableActorError };
