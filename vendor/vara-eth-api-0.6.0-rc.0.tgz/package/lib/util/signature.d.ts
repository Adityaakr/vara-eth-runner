import { type Hex, type Signature } from 'viem';
/**
 * Extracts `r`, `s`, and `v` components from a signature.
 * Derives `v` from `yParity` (0 → 27, 1 → 28) when `v` is not present.
 *
 * @param signature - The viem signature object
 * @returns An object with `r`, `s`, and numeric `v` components ready for ABI encoding
 */
export declare function getRVSComponents(signature: Signature | Hex): {
    r: `0x${string}`;
    s: `0x${string}`;
    v: number;
};
