export declare function convertEventParams<T>(event: any): T;
