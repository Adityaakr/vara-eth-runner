export declare const generateCodeHash: (code: Uint8Array | `0x${string}`) => `0x${string}`;
