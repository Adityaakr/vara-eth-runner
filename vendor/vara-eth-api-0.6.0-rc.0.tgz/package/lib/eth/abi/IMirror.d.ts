export declare const IMIRROR_ABI: readonly [{
    readonly type: "function";
    readonly name: "claimValue";
    readonly inputs: readonly [{
        readonly name: "_claimedId";
        readonly type: "bytes32";
        readonly internalType: "bytes32";
    }];
    readonly outputs: readonly [];
    readonly stateMutability: "nonpayable";
}, {
    readonly type: "function";
    readonly name: "executableBalanceTopUp";
    readonly inputs: readonly [{
        readonly name: "_value";
        readonly type: "uint128";
        readonly internalType: "uint128";
    }];
    readonly outputs: readonly [];
    readonly stateMutability: "nonpayable";
}, {
    readonly type: "function";
    readonly name: "executableBalanceTopUpWithPermit";
    readonly inputs: readonly [{
        readonly name: "_value";
        readonly type: "uint128";
        readonly internalType: "uint128";
    }, {
        readonly name: "_deadline";
        readonly type: "uint256";
        readonly internalType: "uint256";
    }, {
        readonly name: "_v";
        readonly type: "uint8";
        readonly internalType: "uint8";
    }, {
        readonly name: "_r";
        readonly type: "bytes32";
        readonly internalType: "bytes32";
    }, {
        readonly name: "_s";
        readonly type: "bytes32";
        readonly internalType: "bytes32";
    }];
    readonly outputs: readonly [];
    readonly stateMutability: "nonpayable";
}, {
    readonly type: "function";
    readonly name: "exited";
    readonly inputs: readonly [];
    readonly outputs: readonly [{
        readonly name: "";
        readonly type: "bool";
        readonly internalType: "bool";
    }];
    readonly stateMutability: "view";
}, {
    readonly type: "function";
    readonly name: "inheritor";
    readonly inputs: readonly [];
    readonly outputs: readonly [{
        readonly name: "";
        readonly type: "address";
        readonly internalType: "address";
    }];
    readonly stateMutability: "view";
}, {
    readonly type: "function";
    readonly name: "initializer";
    readonly inputs: readonly [];
    readonly outputs: readonly [{
        readonly name: "";
        readonly type: "address";
        readonly internalType: "address";
    }];
    readonly stateMutability: "view";
}, {
    readonly type: "function";
    readonly name: "nonce";
    readonly inputs: readonly [];
    readonly outputs: readonly [{
        readonly name: "";
        readonly type: "uint256";
        readonly internalType: "uint256";
    }];
    readonly stateMutability: "view";
}, {
    readonly type: "function";
    readonly name: "router";
    readonly inputs: readonly [];
    readonly outputs: readonly [{
        readonly name: "";
        readonly type: "address";
        readonly internalType: "address";
    }];
    readonly stateMutability: "view";
}, {
    readonly type: "function";
    readonly name: "sendMessage";
    readonly inputs: readonly [{
        readonly name: "_payload";
        readonly type: "bytes";
        readonly internalType: "bytes";
    }, {
        readonly name: "_callReply";
        readonly type: "bool";
        readonly internalType: "bool";
    }];
    readonly outputs: readonly [{
        readonly name: "messageId";
        readonly type: "bytes32";
        readonly internalType: "bytes32";
    }];
    readonly stateMutability: "payable";
}, {
    readonly type: "function";
    readonly name: "sendReply";
    readonly inputs: readonly [{
        readonly name: "_repliedTo";
        readonly type: "bytes32";
        readonly internalType: "bytes32";
    }, {
        readonly name: "_payload";
        readonly type: "bytes";
        readonly internalType: "bytes";
    }];
    readonly outputs: readonly [];
    readonly stateMutability: "payable";
}, {
    readonly type: "function";
    readonly name: "stateHash";
    readonly inputs: readonly [];
    readonly outputs: readonly [{
        readonly name: "";
        readonly type: "bytes32";
        readonly internalType: "bytes32";
    }];
    readonly stateMutability: "view";
}, {
    readonly type: "event";
    readonly name: "ExecutableBalanceTopUpRequested";
    readonly inputs: readonly [{
        readonly name: "value";
        readonly type: "uint128";
        readonly indexed: false;
        readonly internalType: "uint128";
    }];
    readonly anonymous: false;
}, {
    readonly type: "event";
    readonly name: "Message";
    readonly inputs: readonly [{
        readonly name: "id";
        readonly type: "bytes32";
        readonly indexed: false;
        readonly internalType: "bytes32";
    }, {
        readonly name: "destination";
        readonly type: "address";
        readonly indexed: true;
        readonly internalType: "address";
    }, {
        readonly name: "payload";
        readonly type: "bytes";
        readonly indexed: false;
        readonly internalType: "bytes";
    }, {
        readonly name: "value";
        readonly type: "uint128";
        readonly indexed: false;
        readonly internalType: "uint128";
    }];
    readonly anonymous: false;
}, {
    readonly type: "event";
    readonly name: "MessageCallFailed";
    readonly inputs: readonly [{
        readonly name: "id";
        readonly type: "bytes32";
        readonly indexed: false;
        readonly internalType: "bytes32";
    }, {
        readonly name: "destination";
        readonly type: "address";
        readonly indexed: true;
        readonly internalType: "address";
    }, {
        readonly name: "value";
        readonly type: "uint128";
        readonly indexed: false;
        readonly internalType: "uint128";
    }];
    readonly anonymous: false;
}, {
    readonly type: "event";
    readonly name: "MessageQueueingRequested";
    readonly inputs: readonly [{
        readonly name: "id";
        readonly type: "bytes32";
        readonly indexed: false;
        readonly internalType: "bytes32";
    }, {
        readonly name: "source";
        readonly type: "address";
        readonly indexed: true;
        readonly internalType: "address";
    }, {
        readonly name: "payload";
        readonly type: "bytes";
        readonly indexed: false;
        readonly internalType: "bytes";
    }, {
        readonly name: "value";
        readonly type: "uint128";
        readonly indexed: false;
        readonly internalType: "uint128";
    }, {
        readonly name: "callReply";
        readonly type: "bool";
        readonly indexed: false;
        readonly internalType: "bool";
    }];
    readonly anonymous: false;
}, {
    readonly type: "event";
    readonly name: "OwnedBalanceTopUpRequested";
    readonly inputs: readonly [{
        readonly name: "value";
        readonly type: "uint128";
        readonly indexed: false;
        readonly internalType: "uint128";
    }];
    readonly anonymous: false;
}, {
    readonly type: "event";
    readonly name: "Reply";
    readonly inputs: readonly [{
        readonly name: "payload";
        readonly type: "bytes";
        readonly indexed: false;
        readonly internalType: "bytes";
    }, {
        readonly name: "value";
        readonly type: "uint128";
        readonly indexed: false;
        readonly internalType: "uint128";
    }, {
        readonly name: "replyTo";
        readonly type: "bytes32";
        readonly indexed: false;
        readonly internalType: "bytes32";
    }, {
        readonly name: "replyCode";
        readonly type: "bytes4";
        readonly indexed: true;
        readonly internalType: "bytes4";
    }];
    readonly anonymous: false;
}, {
    readonly type: "event";
    readonly name: "ReplyCallFailed";
    readonly inputs: readonly [{
        readonly name: "value";
        readonly type: "uint128";
        readonly indexed: false;
        readonly internalType: "uint128";
    }, {
        readonly name: "replyTo";
        readonly type: "bytes32";
        readonly indexed: false;
        readonly internalType: "bytes32";
    }, {
        readonly name: "replyCode";
        readonly type: "bytes4";
        readonly indexed: true;
        readonly internalType: "bytes4";
    }];
    readonly anonymous: false;
}, {
    readonly type: "event";
    readonly name: "ReplyQueueingRequested";
    readonly inputs: readonly [{
        readonly name: "repliedTo";
        readonly type: "bytes32";
        readonly indexed: false;
        readonly internalType: "bytes32";
    }, {
        readonly name: "source";
        readonly type: "address";
        readonly indexed: true;
        readonly internalType: "address";
    }, {
        readonly name: "payload";
        readonly type: "bytes";
        readonly indexed: false;
        readonly internalType: "bytes";
    }, {
        readonly name: "value";
        readonly type: "uint128";
        readonly indexed: false;
        readonly internalType: "uint128";
    }];
    readonly anonymous: false;
}, {
    readonly type: "event";
    readonly name: "ReplyTransferFailed";
    readonly inputs: readonly [{
        readonly name: "destination";
        readonly type: "address";
        readonly indexed: false;
        readonly internalType: "address";
    }, {
        readonly name: "value";
        readonly type: "uint128";
        readonly indexed: false;
        readonly internalType: "uint128";
    }];
    readonly anonymous: false;
}, {
    readonly type: "event";
    readonly name: "StateChanged";
    readonly inputs: readonly [{
        readonly name: "stateHash";
        readonly type: "bytes32";
        readonly indexed: false;
        readonly internalType: "bytes32";
    }];
    readonly anonymous: false;
}, {
    readonly type: "event";
    readonly name: "TransferLockedValueToInheritorFailed";
    readonly inputs: readonly [{
        readonly name: "inheritor";
        readonly type: "address";
        readonly indexed: false;
        readonly internalType: "address";
    }, {
        readonly name: "value";
        readonly type: "uint128";
        readonly indexed: false;
        readonly internalType: "uint128";
    }];
    readonly anonymous: false;
}, {
    readonly type: "event";
    readonly name: "ValueClaimFailed";
    readonly inputs: readonly [{
        readonly name: "claimedId";
        readonly type: "bytes32";
        readonly indexed: false;
        readonly internalType: "bytes32";
    }, {
        readonly name: "value";
        readonly type: "uint128";
        readonly indexed: false;
        readonly internalType: "uint128";
    }];
    readonly anonymous: false;
}, {
    readonly type: "event";
    readonly name: "ValueClaimed";
    readonly inputs: readonly [{
        readonly name: "claimedId";
        readonly type: "bytes32";
        readonly indexed: false;
        readonly internalType: "bytes32";
    }, {
        readonly name: "value";
        readonly type: "uint128";
        readonly indexed: false;
        readonly internalType: "uint128";
    }];
    readonly anonymous: false;
}, {
    readonly type: "event";
    readonly name: "ValueClaimingRequested";
    readonly inputs: readonly [{
        readonly name: "claimedId";
        readonly type: "bytes32";
        readonly indexed: false;
        readonly internalType: "bytes32";
    }, {
        readonly name: "source";
        readonly type: "address";
        readonly indexed: true;
        readonly internalType: "address";
    }];
    readonly anonymous: false;
}, {
    readonly type: "error";
    readonly name: "AbiInterfaceAlreadySet";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "CallerNotRouter";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "EnforcedPause";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "EtherTransferToRouterFailed";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "InheritorMustBeZero";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "InitMessageNotCreated";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "InitMessageNotCreatedAndCallerNotInitializer";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "InitializerAlreadySet";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "InvalidActorId";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "InvalidFallbackCall";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "IsSmallAlreadySet";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "ProgramExited";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "ProgramNotExited";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "TransferLockedValueToInheritorExternalFailed";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "WVaraTransferFailed";
    readonly inputs: readonly [];
}];
/**
 * Interface for IMirror contract methods
 */
export interface IMirrorContract {
    /**
     * Checks if the program has exited
     * @returns Promise resolving to true if exited
     */
    exited(): Promise<boolean>;
    /**
     * Gets the inheritor address
     * @returns Promise resolving to the inheritor address
     */
    inheritor(): Promise<string>;
    /**
     * Gets the initializer address
     * @returns Promise resolving to the initializer address
     */
    initializer(): Promise<string>;
    /**
     * Gets the current nonce
     * @returns Promise resolving to the nonce
     */
    nonce(): Promise<bigint>;
    /**
     * Gets the router address
     * @returns Promise resolving to the router address
     */
    router(): Promise<string>;
    /**
     * Gets the current state hash
     * @returns Promise resolving to the state hash
     */
    stateHash(): Promise<string>;
}
