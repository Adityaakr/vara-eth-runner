import type { Abi, TypedDataDomain, WatchContractEventReturnType } from 'viem';
import type { LogCallbackParams } from '../interfaces/logs/base.log.js';
import { BaseContractClient } from './base.contract.js';
/** Base class for contracts that implement EIP-712 typed-data signing (ERC-5267). */
export declare class EIP712ContractClient<const abi extends Abi> extends BaseContractClient<abi> {
    private _cachedDomain;
    /**
     * Returns the EIP-712 domain for this contract, fetching and caching it on first call.
     * @returns The typed-data domain with only the fields active per the EIP-5267 `fields` bitmask
     */
    eip712Domain(): Promise<TypedDataDomain>;
    /**
     * Subscribes to `EIP712DomainChanged` events emitted when the domain is updated.
     * @param callback - Called with block/tx metadata for each event log
     * @returns Unwatch function — call it to stop listening
     */
    watchEIP712DomainChangedEvent(callback: (params: LogCallbackParams) => void): WatchContractEventReturnType;
}
