import type { Address, Hex, Signature } from 'viem';
import { IWRAPPEDVARA_ABI, type IWrappedVaraContract } from '../abi/IWrappedVara.js';
import type { ITxManager, TxManagerWithHelpers } from '../interfaces/tx-manager.js';
import type { WrappedVaraTxHelpers, WVaraTransferHelpers } from '../interfaces/wrappedVara.js';
import type { ContractClientParams } from './base.contract.js';
import { EIP712ContractClient } from './eip-712.contract.js';
/**
 * Contract client for the WrappedVara (WVARA) ERC-20 token.
 *
 * WrappedVara is an ERC-20 token with EIP-2612 permit support (EIP-712 signed approvals).
 * It is used throughout the co-processor as the payment token for fees and executable balances.
 */
export declare class WrappedVaraClient extends EIP712ContractClient<typeof IWRAPPEDVARA_ABI> implements IWrappedVaraContract {
    private _cachedDecimals;
    private _cachedName;
    private _cachedSymbol;
    constructor(params: Omit<ContractClientParams, 'abi'>);
    /**
     * Returns the EIP-2612 permit nonce for the given owner address.
     * @param owner - Token holder address
     */
    nonces(owner: Address): Promise<bigint>;
    /** Returns the owner address of the WrappedVara contract. */
    owner(): Promise<string>;
    /**
     * Returns the remaining token allowance that `spender` may transfer on behalf of `owner`.
     * @param owner - Token holder address
     * @param spender - Approved spender address
     */
    allowance(owner: Address, spender: Address): Promise<bigint>;
    /**
     * Returns the WVARA token balance of the given account.
     * @param account - Address to query
     */
    balanceOf(account: Address): Promise<bigint>;
    /** Returns the number of decimals used by the token (cached after first fetch). */
    decimals(): Promise<number>;
    /** Returns the token name (cached after first fetch). */
    name(): Promise<string>;
    /** Returns the token symbol (cached after first fetch). */
    symbol(): Promise<string>;
    /** Returns the total WVARA token supply. */
    totalSupply(): Promise<bigint>;
    /**
     * Approves the specified address to spend the specified amount of tokens on behalf of the caller.
     *
     * @param spender - The address to be approved for spending
     * @param value - The amount of tokens to be approved for spending
     * @returns A transaction manager with approval-specific helper functions
     */
    approve(spender: Address, value: bigint): Promise<TxManagerWithHelpers<WrappedVaraTxHelpers>>;
    transfer(to: Address, value: bigint): Promise<TxManagerWithHelpers<WVaraTransferHelpers>>;
    permit(owner: Address, spender: Address, value: bigint, deadline: bigint, permitSignature: Signature | Hex): ITxManager;
    /**
     * Prepares and signs permit data for the given spender, value, and deadline.
     * @param spender The address of the spender.
     * @param value The value to be approved.
     * @param deadline The deadline for the permit.
     *
     * @returns The owner, spender, value, deadline, and signature of the permit.
     */
    prepareAndSignPermitData(spender: Address, value: bigint, deadline: bigint): Promise<{
        owner: Address;
        spender: Address;
        value: bigint;
        deadline: bigint;
        signature: Hex;
    }>;
}
/**
 * Creates a new WrappedVaraContract instance.
 *
 * @param params - {@link ContractClientParams} parameters for creating the WrappedVara contract client
 * @returns A new {@link WrappedVaraClient} instance that implements the {@link IWrappedVaraContract} interface
 */
export declare function getWrappedVaraClient(params: Omit<ContractClientParams, 'abi'>): WrappedVaraClient;
