import type { Address, Hex, Signature, TransactionRequestBase } from 'viem';
import { IMIRROR_ABI, type IMirrorContract } from '../abi/IMirror.js';
import type { ITxManager, MessageHelpers, Reply, ReplyHelpers, TxManagerWithHelpers, ValueClaimingRequestedLog } from '../interfaces/index.js';
import { BaseContractClient, type ContractClientParams } from './base.contract.js';
/**
 * Contract client for the Mirror contract.
 *
 * Mirror is the on-chain representation of a Gear program deployed inside the co-processor.
 * It exposes methods to send messages/replies, claim values, and top up the program's
 * executable balance. Every mutating call emits a *requesting* event that validator nodes
 * pick up and process inside the co-processor.
 */
export declare class MirrorClient extends BaseContractClient<typeof IMIRROR_ABI> implements IMirrorContract {
    private _cachedRouter;
    constructor(params: Omit<ContractClientParams, 'abi'>);
    /** Returns `true` if the program has exited. */
    exited(): Promise<boolean>;
    /**
     * Returns the address of the `Router` contract that governs this Mirror.
     * Result is fetched once and cached for subsequent calls.
     */
    router(): Promise<Address>;
    /** Returns the current state hash of the program. */
    stateHash(): Promise<Hex>;
    /**
     * Returns the nonce used to generate unique message IDs.
     * Incremented with each message received from Ethereum; nonce 0 is always the init message.
     */
    nonce(): Promise<bigint>;
    /**
     * Returns the inheritor address set by the program on exit.
     * Any remaining program value is transferred to this address after exit.
     */
    inheritor(): Promise<Address>;
    /** Returns the address eligible to send the first (init) message to the program. */
    initializer(): Promise<Address>;
    /**
     * Sends a message to the Mirror contract.
     *
     * @param payload - The message payload
     * @param value - The value to send with the message (in wei)
     * @returns A transaction manager with message-specific helper functions
     */
    sendMessage(payload: string, value?: bigint, options?: Omit<TransactionRequestBase, 'to' | 'data' | 'value' | 'from' | 'type'>): Promise<TxManagerWithHelpers<MessageHelpers>>;
    /**
     * Sends a reply to a previously received message.
     *
     * @param repliedTo - The ID of the message being replied to
     * @param payload - The reply payload
     * @param value - The value to send with the reply (in wei)
     * @returns A transaction manager with reply-specific helper functions
     */
    sendReply(repliedTo: string, payload: string, value?: bigint): Promise<TxManagerWithHelpers<ReplyHelpers>>;
    /**
     * Claims a value associated with the given ID.
     *
     * @param claimedId - The ID of the value to claim
     * @returns A transaction manager with claim-specific helper functions
     */
    claimValue(claimedId: string): Promise<TxManagerWithHelpers<{
        getValueClaimingRequestedEvent: () => Promise<ValueClaimingRequestedLog>;
    }>>;
    /**
     * Tops up the executable balance of the program.
     *
     * @param value - The amount to top up
     */
    executableBalanceTopUp(value: bigint): Promise<ITxManager>;
    /**
     * Tops up the executable balance with permit
     * @param value - The amount to top up
     * @param deadline - Signature deadline
     * @param permitSignature - Signature of the permit
     */
    executableBalanceTopUpWithPermit(value: bigint, deadline: bigint, permitSignature: Signature | Hex): Promise<ITxManager>;
    /**
     * Listens to StateChanged event on the mirror contract.
     * @param callback - a function that will be invoked with the new state hash when a StateChanged event occurs
     * @returns An unwatch function that can be called to stop listening to events
     */
    watchStateChangedEvent(callback: (newStateHash: Hex) => void): import("viem").WatchContractEventReturnType;
    /**
     * Waits for a `Reply` event matching the given message ID.
     * @param messageId - ID of the sent message to wait for a reply to
     * @param fromBlockNumber - Start scanning from this block (use the send-tx block number to avoid missing events)
     * @returns Resolved reply payload, value, reply code, block number, and tx hash
     */
    waitForReply(messageId: Hex, fromBlockNumber?: bigint): Promise<Reply>;
}
/**
 * Creates a new MirrorContract instance.
 *
 * @param params - {@link ContractClientParams} parameters for creating the Mirror contract client
 * @returns A new {@link MirrorClient} instance that implements the {@link IMirrorContract} interface
 */
export declare function getMirrorClient(params: Omit<ContractClientParams, 'abi'>): MirrorClient;
