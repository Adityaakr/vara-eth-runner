import type { IVaraEthProvider } from '../../types/index.js';
export declare class InfoQueries {
    private _provider;
    constructor(_provider: IVaraEthProvider);
    /**
     * Fetches the node's RPC version string.
     *
     * Returns `null` if the node does not implement the `version` RPC method (legacy node).
     * A `null` return causes {@link VaraEthApi} to fall back to the legacy injected
     * transaction format.
     */
    version(): Promise<string | null>;
}
