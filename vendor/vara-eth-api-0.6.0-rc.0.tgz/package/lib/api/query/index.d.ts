import { BlockQueries } from './block.js';
import { CodeQueries } from './code.js';
import { InfoQueries } from './info.js';
import { InjectedQueries } from './injected.js';
import { ProgramQueries } from './program.js';
export declare const query: {
    readonly block: typeof BlockQueries;
    readonly code: typeof CodeQueries;
    readonly program: typeof ProgramQueries;
    readonly injected: typeof InjectedQueries;
    readonly info: typeof InfoQueries;
};
export type Query = {
    block: BlockQueries;
    code: CodeQueries;
    program: ProgramQueries;
    injected: InjectedQueries;
    info: InfoQueries;
};
