import type { Hash, Hex } from 'viem';
import { ReplyCode } from '../../errors/index.js';
import type { EthereumClient } from '../../eth/index.js';
import type { IInjectedTransactionPromise } from '../../types/index.js';
/**
 * @deprecated
 */
export type LegacyInjectedTransactionPromiseRaw = {
    data: {
        txHash: Hash;
        reply: {
            payload: Hex;
            value: number;
            code: Hex;
        };
    };
    signature: Hex;
};
/**
 * @deprecated
 */
export declare class InjectedTxPromise implements IInjectedTransactionPromise {
    private _ethClient;
    /**
     * The hash of the original injected transaction
     */
    readonly txHash: Hash;
    /**
     * The payload of the reply message
     */
    readonly payload: Hex;
    /**
     * The value (in wei) associated with the reply
     */
    readonly value: bigint;
    /**
     * The reply code indicating the result status
     */
    readonly code: ReplyCode;
    /**
     * The validator's signature for this promise
     */
    readonly signature: Hex;
    private _validatorAddress?;
    constructor(promise: LegacyInjectedTransactionPromiseRaw, _ethClient: EthereumClient);
    /**
     * Validates that the promise signature was created by an authorized validator
     * @throws {Error} If the signature is invalid or not from a registered validator
     */
    validateSignature(): Promise<void>;
    /**
     * Returns the address of the validator that signed the promise
     * @throws {Error} If the signature is not validated yet
     */
    get validatorAddress(): `0x${string}`;
    private get _dataU8a();
    private get _replyDataU8a();
    private get _replyHashU8a();
    get replyHash(): Hash;
    /**
     * Computes the keccak256 hash of the promise data (txHash + replyInfoHash)
     * @returns The hash used for signature verification
     */
    get hash(): Hash;
    private get _payloadU8a();
    private get _txHashU8a();
    private get _codeU8a();
    private get _valueU8a();
}
