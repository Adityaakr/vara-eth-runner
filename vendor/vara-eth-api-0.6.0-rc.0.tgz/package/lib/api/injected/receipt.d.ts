import { type Address, type Hash, type Hex } from 'viem';
import { ReplyCode } from '../../errors/reply-code.js';
import type { EthereumClient } from '../../eth/ethereumClient.js';
export type InjectedTransactionPromiseRaw = {
    readonly Promise: {
        readonly txHash: Hash;
        readonly reply: {
            readonly payload: Hex;
            readonly value: number;
            readonly code: Hex;
        };
    };
};
export type InjectedTransactionPurgedRaw = {
    readonly Purged: {
        readonly txHash: Hash;
        readonly reason: number | string;
    };
};
export type InjectedTransactionReceiptRaw = {
    readonly data: InjectedTransactionPromiseRaw | InjectedTransactionPurgedRaw;
    readonly signature: Hex;
    readonly address: Address;
};
export type InjectedTransactionPromise = {
    /** The payload of the reply message */
    readonly payload: Hex;
    /** The value (in wei) associated with the reply */
    readonly value: bigint;
    /** The reply code indicating the result status */
    readonly code: ReplyCode;
};
/**
 * Mirrors `TransactionPurgedReason` from the Rust implementation (`#[repr(u8)]`).
 * Values not listed here may appear for future purge reasons.
 */
export declare enum TransactionPurgedReason {
    /** The transaction references an outdated block and cannot be included. */
    Outdated = 1,
    /** The transaction references a block that is not known locally. */
    UnknownReferenceBlock = 2,
    /** The transaction has a non-zero value, which is not supported yet. */
    NonZeroValue = 255
}
/**
 * Represents a signed receipt returned by the node after an injected transaction is processed.
 *
 * A receipt is one of two variants:
 * - **Promise** — the transaction was executed and a reply was produced. Access reply data via {@link promise}.
 * - **Purged** — the transaction was dropped before execution. Access the reason via {@link error} or {@link purgedReason}.
 *
 * Always call {@link validateSignature} before trusting reply data.
 */
export declare class InjectedTxReceipt {
    private _ethClient;
    /** ECDSA signature over {@link hash}, produced by the validator. */
    readonly signature: Hex;
    /** Lowercase Ethereum address of the validator that signed this receipt. */
    readonly address: Address;
    /** The injected transaction hash this receipt corresponds to. */
    readonly txHash: Hash;
    private readonly _promise;
    private readonly _error;
    constructor(receipt: InjectedTransactionReceiptRaw, _ethClient: EthereumClient);
    /**
     * Validates that this receipt was signed by a registered validator.
     *
     * Recovers the signer from {@link signature} over {@link hash} and checks:
     * 1. The recovered address matches {@link address} reported in the receipt.
     * 2. That address appears in the on-chain validator set.
     *
     * @throws {Error} If the recovered address does not match the receipt address.
     * @throws {Error} If the recovered address is not a registered validator.
     */
    validateSignature(): Promise<void>;
    /**
     * Human-readable description of why this receipt is in a Purged state, or `null` for a successful Promise receipt.
     *
     * Returns `null` when the receipt is a Promise (success).
     * Returns a decoded reason string for known {@link TransactionPurgedReason} values.
     * Returns `'unknown purge reason: <code>'` for unrecognized codes.
     * Returns `'Unknown error'` if the receipt is neither Promise nor Purged (should not occur in practice).
     */
    get error(): string | null;
    /**
     * The raw purge reason code, or `null` for a Promise receipt.
     *
     * Use this for programmatic branching on the purge reason.
     * Values correspond to {@link TransactionPurgedReason}; unrecognized future codes are returned as-is.
     */
    get purgedReason(): number | null;
    /**
     * The reply data from a successfully executed transaction.
     *
     * @throws {Error} If the receipt is Purged — check `error === null` before accessing this getter,
     * or catch the thrown error.
     */
    get promise(): InjectedTransactionPromise;
    /**
     * The receipt hash used as the signed message by the validator.
     *
     * Encoding: `keccak256([variant_tag] ‖ txHash ‖ inner_hash)` where:
     * - Promise variant: `tag = 0x00`, `inner_hash = replyHash`
     * - Purged variant: `tag = 0x01`, `inner_hash = reason_byte`
     *
     * @throws {Error} If the receipt is in an unexpected state (neither Promise nor Purged).
     */
    get hash(): Hash;
    /**
     * blake2b-256 hash of the reply info: `blake2b(payload ‖ value ‖ code)`.
     * Used as the `inner_hash` component of {@link hash} for Promise receipts.
     *
     * @throws {Error} If the receipt is Purged (no reply info to hash).
     */
    get replyHash(): Hash;
    private get _payloadU8a();
    private get _txHashU8a();
    private get _codeU8a();
    private get _valueU8a();
    private get _replyHashU8a();
}
