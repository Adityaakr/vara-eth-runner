import type { Address, Hash, Hex } from 'viem';
import type { EthereumClient } from '../../eth/index.js';
import type { IInjectedTransaction, IMessageSigner, IVaraEthProvider, IVaraEthValidatorPoolProvider } from '../../types/index.js';
import { InjectedTxPromise } from './promise.js';
import { InjectedTxReceipt } from './receipt.js';
export declare class InjectedTx {
    private _varaethProvider;
    private _ethClient;
    private _apiVersion?;
    private _destination;
    private _payload;
    private _value;
    private _referenceBlock;
    private _salt;
    private _recipient?;
    private _signature;
    private _account;
    constructor(_varaethProvider: IVaraEthProvider | IVaraEthValidatorPoolProvider, _ethClient: EthereumClient, tx: IInjectedTransaction, _apiVersion?: string | null | undefined);
    private _trySetActiveValidator;
    get destination(): Hex;
    private get _destinationU8a();
    get recipient(): Address | null;
    get payload(): Hex;
    private get _payloadU8a();
    private get _payloadHashU8a();
    get value(): bigint;
    private get _valueU8a();
    get referenceBlock(): Hex | null;
    private get _referenceBlockU8a();
    get salt(): Hex;
    private get _saltU8a();
    private get _saltHashU8a();
    private get _hashableBytes();
    private get _bytes();
    private get _bytesBasedOnVersion();
    get hash(): Hex;
    get messageId(): Hex;
    get txHash(): Hex;
    private get _data();
    setValue(value: bigint): this;
    setSalt(value: Hex): this;
    setReferenceBlock(blockHash?: Hash): Promise<void>;
    /**
     * @deprecated recipient field was removed from the transaction data. The method is to be removed in the next release
     * ## Specify validator address the transaction is intended for
     * @param address - (optional) the validator address. If omitted, defaults to the validator assigned to the current slot via {@link setSlotValidator}. Use {@link setDefaultValidator} to explicitly target no specific validator.
     * @returns the validator address
     */
    setRecipient(address?: Address): Promise<Address>;
    /**
     * @deprecated recipient field was removed from the transaction data. The method is to be removed in the next release
     * ## Target the validator assigned to the current slot
     *
     * Computes the validator scheduled to process the imminent block using slot-based
     * round-robin (`floor(timestamp / blockDuration) % validators.length`), where the
     * timestamp is projected two blocks ahead to account for network propagation.
     *
     * Sets the computed address as the transaction {@link recipient}. If the provider is a
     * {@link IVaraEthValidatorPoolProvider | validator pool} and the address is present in the
     * pool, subsequent sends are routed directly to that validator's RPC connection. Otherwise
     * the transaction is forwarded by the receiving node.
     *
     * @returns The selected validator address
     */
    setSlotValidator(): Promise<`0x${string}`>;
    /** @deprecated Use {@link setSlotValidator} instead */
    setNextValidator(): Promise<`0x${string}`>;
    /**
     * @deprecated recipient field was removed from the transaction data. The method is to be removed in the next release
     * ## Let any validator process the transaction
     *
     * Sets the recipient to the zero address, signalling that no specific validator is
     * targeted. The receiving node will include the transaction in the next available slot
     * regardless of which validator produces it.
     *
     * Use this when validator targeting is not important and you want the simplest, most
     * reliable delivery path.
     *
     * @returns The zero address
     */
    setDefaultValidator(): Address;
    private get _rpcData();
    /**
     * ## Sign the injected transaction
     * @returns The signature of the transaction
     */
    sign(signer?: IMessageSigner): Promise<`0x${string}`>;
    /**
     * ## Send the injected transaction
     */
    send(): Promise<string>;
    /**
     * Send the transaction and wait for the validator's signed receipt.
     *
     * Automatically signs and sets a reference block if not already done.
     * Opens a subscription to `sendTransactionAndWatch` and resolves with an
     * {@link InjectedTxReceipt} on the first notification. The subscription is
     * cancelled immediately after the receipt arrives.
     *
     * Check {@link InjectedTxReceipt.error} to distinguish a successful Promise
     * receipt from a Purged receipt before accessing reply data.
     */
    sendAndWaitForReceipt(): Promise<InjectedTxReceipt>;
    /**
     *
     * @deprecated The RPC method has been changed and is to be removed in the next release.
     * Use {@link sendAndWaitForReceipt} instead
     */
    sendAndWaitForPromise(): Promise<InjectedTxPromise | InjectedTxReceipt>;
}
