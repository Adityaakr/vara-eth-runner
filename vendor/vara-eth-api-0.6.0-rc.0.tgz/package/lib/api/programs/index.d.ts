import type { Address, Hex } from 'viem';
import type { EthereumClient } from '../../eth/index.js';
import type { IInjectedTransaction } from '../../types/index.js';
import type { InjectedTx } from '../injected/tx.js';
import { type DeployProgramOptions, type DeployProgramResult } from './deploy.js';
import { type ReplyResult, type SendAndWaitOptions } from './send-and-wait.js';
export type { DeployProgramOptions, DeployProgramResult } from './deploy.js';
export { deployProgram } from './deploy.js';
export type { ReplyResult, SendAndWaitOptions, SendPath } from './send-and-wait.js';
export { sendAndWaitForReply } from './send-and-wait.js';
/**
 * Function shape required from {@link VaraEthApi.createInjectedTransaction}.
 * Decoupling via a callback keeps `ProgramsNamespace` free of a back-reference
 * to the full `VaraEthApi` instance (which would create a construction-order
 * cycle).
 */
export type CreateInjectedTransaction = (tx: IInjectedTransaction) => Promise<InjectedTx>;
/**
 * Convenience namespace attached to {@link VaraEthApi} as `api.programs`.
 *
 * Wraps the multi-step ceremonies (code upload → validation wait → deploy;
 * send → reply wait) so callers don't have to drive them by hand.
 */
export declare class ProgramsNamespace {
    private readonly _ethClient;
    private readonly _createInjectedTransaction;
    constructor(_ethClient: EthereumClient, _createInjectedTransaction: CreateInjectedTransaction);
    /** See {@link deployProgram}. */
    deploy(code: Uint8Array, options?: DeployProgramOptions): Promise<DeployProgramResult>;
    /** See {@link sendAndWaitForReply}. */
    sendAndWait(mirror: Address, payload: Hex, options?: SendAndWaitOptions): Promise<ReplyResult>;
}
