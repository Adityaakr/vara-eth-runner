import type { EthereumClient } from '../eth/index.js';
import type { IInjectedTransaction, IVaraEthProvider, IVaraEthValidatorPoolProvider } from '../types/index.js';
import { type Call } from './call/index.js';
import { FeesNamespace } from './fees/index.js';
import { InjectedTx } from './injected/index.js';
import { ProgramsNamespace } from './programs/index.js';
import { type Query } from './query/index.js';
import { StreamNamespace } from './stream/index.js';
export declare class VaraEthApi {
    private _ethClient?;
    private _provider;
    private _rpcVersion;
    readonly query: Query;
    readonly call: Call;
    /**
     * High-level program operations: `deploy` and `sendAndWait`.
     * Available only when an {@link EthereumClient} is wired in (i.e. the api was
     * created via `createVaraEthApi`). Accessing a method when no EthereumClient
     * is set throws a clear error.
     */
    readonly programs: ProgramsNamespace;
    /**
     * Fee-estimation helpers.
     * Available only when an {@link EthereumClient} is wired in.
     */
    readonly fees: FeesNamespace;
    /**
     * Typed event streams over Router and Mirror contracts, plus block headers.
     * Available only when an {@link EthereumClient} is wired in.
     */
    readonly stream: StreamNamespace;
    constructor(provider: IVaraEthProvider | IVaraEthValidatorPoolProvider, _ethClient?: EthereumClient | undefined);
    /**
     * Creates a fully initialized `VaraEthApi` by fetching the node's RPC version.
     *
     * The RPC version determines which transaction format is used for injected transactions:
     * versioned nodes use the compact `{ data, signature, address }` payload and return
     * {@link InjectedTxReceipt}; unversioned or legacy nodes fall back to the old
     * `{ recipient, tx }` format.
     *
     * Prefer {@link createVaraEthApi} for external use — it constructs and initializes
     * the `EthereumClient` as well.
     */
    static create(provider: IVaraEthProvider | IVaraEthValidatorPoolProvider, ethClient?: EthereumClient): Promise<VaraEthApi>;
    private _setProps;
    get provider(): IVaraEthProvider | IVaraEthValidatorPoolProvider;
    get eth(): EthereumClient;
    createInjectedTransaction(tx: IInjectedTransaction): Promise<InjectedTx>;
    /**
     * The RPC version reported by the connected node, or `null` if the node does not
     * support the `version` RPC method (legacy node) or if this instance was constructed
     * directly without {@link create}.
     *
     * A non-null, non-`'0.0.0'` value enables the versioned injected transaction path.
     */
    get rpcVersion(): string | null;
}
