export declare const VARA_ETH_RPC_METHODS: {
    readonly injected: {
        readonly sendTransaction: "injected_sendTransaction";
        readonly sendTransactionAndWatch: {
            readonly subscribe: "injected_sendTransactionAndWatch";
            readonly unsubscribe: "injected_sendTransactionAndWatchUnsubscribe";
        };
    };
};
