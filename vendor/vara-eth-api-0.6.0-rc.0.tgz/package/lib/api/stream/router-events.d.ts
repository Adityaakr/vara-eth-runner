import type { Address, PublicClient } from 'viem';
import { type RouterEvent, type StreamHandlers, type Unsubscribe, type WatchEventsOptions } from './types.js';
export type WatchRouterEventsOptions = WatchEventsOptions;
/**
 * Subscribes to all events emitted by the Router contract and dispatches them
 * through a typed discriminated union.
 *
 * Wraps viem's `publicClient.watchContractEvent` — re-connection and polling
 * fallback are handled by viem internally.
 *
 * @param publicClient - viem PublicClient
 * @param router - the Router contract address (typically `ethClient.router.address`)
 * @param handlers - {@link StreamHandlers}
 * @param options - {@link WatchRouterEventsOptions}
 * @returns {@link Unsubscribe} call this to stop the stream
 */
export declare function watchRouterEvents(publicClient: PublicClient, router: Address, handlers: StreamHandlers<RouterEvent>, options?: WatchRouterEventsOptions): Unsubscribe;
