import type { Address, Hash, Hex } from 'viem';
import type { ReplyCode } from '../../errors/reply-code.js';
export type MessageId = Hash;
export type DispatchKind = 'Init' | 'Handle' | 'Reply' | 'Signal';
export type PayloadLookup = {
    Direct: Hex;
} | {
    Stored: Hash;
};
export interface ReplyDetails {
    readonly to: MessageId;
    readonly code: ReplyCode;
}
export interface SignalDetails extends Pick<ReplyDetails, 'to'> {
    readonly code: unknown;
}
export type MessageDetails = {
    Reply: ReplyDetails;
} | {
    Signal: SignalDetails;
};
export interface ContextStore {
    readonly initialized: Array<Address>;
    readonly reservationNonce: number;
    readonly systemReservation: number;
    readonly localNonce: number;
}
export type MessageType = 'Canonical' | 'Injected';
export interface Dispatch {
    readonly id: MessageId;
    readonly kind: DispatchKind;
    readonly source: Address;
    readonly payload: PayloadLookup;
    readonly value: bigint;
    readonly details: MessageDetails | null;
    readonly context: ContextStore | null;
    readonly messageType: MessageType;
    readonly call: boolean;
}
