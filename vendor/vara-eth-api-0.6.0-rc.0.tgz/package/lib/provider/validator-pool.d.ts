import type { Address } from 'viem';
import type { ISubscriptionCallback, IVaraEthValidatorPoolProvider } from '../types/index.js';
import { type ConnectionOptions } from './ws.js';
export type ValidatorPool = {
    url: string;
    address: Address;
}[];
export declare class VaraEthValidatorWsPool implements IVaraEthValidatorPoolProvider {
    private options;
    private _validators;
    private _activeValidator;
    readonly isPool = true;
    constructor(pool: ValidatorPool, options?: ConnectionOptions);
    get validatorAddresses(): Address[];
    hasValidator(address: Address): boolean;
    setActiveValidator(address: Address): void;
    removeValidator(address: Address): Promise<void>;
    addValidator(address: Address, url: string): Promise<void>;
    connect(): Promise<void>;
    disconnect(): Promise<void>;
    send<Result = unknown>(method: string, parameters: unknown[], options?: {
        timeout?: number;
    }): Promise<Result>;
    subscribe<Error = unknown, Result = unknown>(method: string, unsubscribeMethod: string, parameters: unknown[], callback: ISubscriptionCallback<Error, Result>): Promise<() => void>;
}
