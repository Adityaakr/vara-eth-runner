import type { HttpUrl, IVaraEthProvider, IVaraEthValidatorPoolProvider, WsUrl } from '../types/index.js';
export declare function isWsUrl(url: string): url is WsUrl;
export declare function isHttpUrl(url: string): url is HttpUrl;
export declare function isPoolProvider(provider: IVaraEthProvider | IVaraEthValidatorPoolProvider): provider is IVaraEthValidatorPoolProvider;
